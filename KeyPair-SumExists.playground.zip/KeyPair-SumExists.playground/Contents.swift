/*
 Given an array Arr of N positive integers and another number X. Determine whether or not there exist two elements in Arr whose sum is exactly X.
*/

//Linear
func isSumExists(array: [Int], target: Int) -> Bool {
    let array = array.filter { $0 <= target }
    var isSumExists = false
    for i in 0..<array.count where !isSumExists {
        for j in i..<array.count where i != j {
            if array[i] + array[j] == target {
                isSumExists = true
                break
            }
        }
    }
    return isSumExists
}

//BinarySearch
func isSumExistsUsingBinarySearch(array: [Int], target: Int) -> Bool {
    let array = array.sorted()
    var i = 0 //initial index
    var j = array.count - 1 // last index
    while i<j {
        let sum = array[i] + array[j]
        guard sum != target else {
            return true
        }
        sum > target ? (j -= 1) : (i += 1)
    }
    return false
}

print(
    isSumExists(
        array: [2, 0, 4, 7 , 0 , 3, 6],
        target: 10
    )
)

print(
    isSumExistsUsingBinarySearch(
        array: [2, 0, 4, 7 , 0 , 3, 6],
        target: 10
    )
)
